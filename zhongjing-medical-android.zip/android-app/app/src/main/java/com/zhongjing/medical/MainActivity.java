package com.zhongjing.medical;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.DocumentsContract;
import android.util.Log;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

/**
 * Main Activity - Hosts the Zhongjing Medical Records Web App in a WebView.
 *
 * The web app files are bundled in assets/www/ and served via a local
 * WebView with a virtual URL scheme to support SPA routing.
 */
@SuppressLint("SetJavaScriptEnabled")
public class MainActivity extends AppCompatActivity {

    private static final String TAG = "Zhongjing";
    private static final String BASE_URL = "https://app.zhongjing.local/";
    private static final String APP_SCHEME = "app";
    private static final String APP_HOST = "zhongjing.local";

    private WebView webView;
    private ProgressBar progressBar;
    private SwipeRefreshLayout swipeRefresh;
    private boolean isPageLoaded = false;

    /** File extensions that should be served as static assets */
    private static final Set<String> ASSET_EXTENSIONS = new HashSet<>(Arrays.asList(
        "js", "css", "png", "jpg", "jpeg", "gif", "svg", "ico", "woff", "woff2",
        "ttf", "eot", "json", "map", "txt"
    ));

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        webView = findViewById(R.id.webView);
        progressBar = findViewById(R.id.progressBar);
        swipeRefresh = findViewById(R.id.swipeRefresh);

        setupWebView();
        setupSwipeRefresh();

        loadApp();
    }

    private void setupWebView() {
        WebSettings settings = webView.getSettings();

        // JavaScript support
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);

        // Allow file access for local storage operations
        settings.setAllowFileAccess(true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
            settings.setAllowFileAccessFromFileURLs(true);
            settings.setAllowUniversalAccessFromFileURLs(true);
        }

        // Caching
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);

        // Display
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(true);
        settings.setSupportZoom(false);

        // Dark mode support
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            settings.setAlgorithmicDarkeningAllowed(true);
        }

        // WebView client to intercept requests and serve local assets
        webView.setWebViewClient(new WebViewClient() {
            @Nullable
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (APP_SCHEME.equals(uri.getScheme()) && APP_HOST.equals(uri.getHost())) {
                    return serveAsset(uri);
                }
                return super.shouldInterceptRequest(view, request);
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                // Handle external links
                if (!APP_SCHEME.equals(uri.getScheme()) || !APP_HOST.equals(uri.getHost())) {
                    if ("http".equals(uri.getScheme()) || "https".equals(uri.getScheme())) {
                        Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                        startActivity(intent);
                        return true;
                    }
                }
                return false;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                isPageLoaded = true;
                progressBar.setVisibility(View.GONE);
                swipeRefresh.setRefreshing(false);
            }
        });

        // Progress tracking
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                progressBar.setProgress(newProgress);
                if (newProgress == 100) {
                    progressBar.setVisibility(View.GONE);
                }
            }
        });
    }

    /**
     * Intercept asset requests and serve from bundled assets.
     * The virtual URL https://app.zhongjing.local/path maps to android_asset://www/path
     */
    @Nullable
    private WebResourceResponse serveAsset(Uri uri) {
        String path = uri.getPath();
        if (path == null || path.isEmpty() || "/".equals(path)) {
            path = "/index.html";
        }

        // Remove leading slash
        String assetPath = "www" + path;

        try {
            InputStream inputStream = getAssets().open(assetPath);
            String mimeType = getMimeType(path);
            return new WebResourceResponse(mimeType, "UTF-8", inputStream);
        } catch (IOException e) {
            // Asset not found - try index.html for SPA routing
            if (!path.endsWith(".html") && !isStaticAsset(path)) {
                try {
                    InputStream inputStream = getAssets().open("www/index.html");
                    return new WebResourceResponse("text/html", "UTF-8", inputStream);
                } catch (IOException ignored) {
                }
            }
            Log.w(TAG, "Asset not found: " + assetPath);
            return null;
        }
    }

    private boolean isStaticAsset(String path) {
        int lastDot = path.lastIndexOf('.');
        if (lastDot > 0 && lastDot < path.length() - 1) {
            String ext = path.substring(lastDot + 1).toLowerCase();
            return ASSET_EXTENSIONS.contains(ext);
        }
        return false;
    }

    private String getMimeType(String path) {
        int lastDot = path.lastIndexOf('.');
        if (lastDot > 0) {
            String ext = path.substring(lastDot + 1).toLowerCase();
            switch (ext) {
                case "html": case "htm": return "text/html";
                case "js": return "application/javascript";
                case "css": return "text/css";
                case "json": return "application/json";
                case "png": return "image/png";
                case "jpg": case "jpeg": return "image/jpeg";
                case "gif": return "image/gif";
                case "svg": return "image/svg+xml";
                case "ico": return "image/x-icon";
                case "woff": return "font/woff";
                case "woff2": return "font/woff2";
                case "ttf": return "font/ttf";
                case "txt": return "text/plain";
                default: return "application/octet-stream";
            }
        }
        return "text/html";
    }

    private void setupSwipeRefresh() {
        swipeRefresh.setColorSchemeResources(
            android.R.color.holo_orange_light,
            android.R.color.holo_orange_dark
        );
        swipeRefresh.setOnRefreshListener(() -> {
            webView.reload();
        });
    }

    private void loadApp() {
        progressBar.setVisibility(View.VISIBLE);
        webView.loadUrl(BASE_URL);
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        webView.saveState(outState);
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        webView.restoreState(savedInstanceState);
    }
}
