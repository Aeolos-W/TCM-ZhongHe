# 仲景医案录 - Android APK 构建指南

## 项目简介

本项目将"仲景医案录"网页应用通过 Android WebView 封装为原生 APK。所有网页资源已嵌入 assets 目录，无需网络即可使用。

**已配置内容：**
- 阿里云 Gradle 镜像（自动加速依赖下载）
- 阿里云 Maven 镜像（自动加速库下载）
- 本地 WebView 资源托管（SPA 路由支持）
- 下拉刷新、加载进度条、返回键拦截

---

## 前置要求

1. **JDK 17+**（`java -version` 检查）
2. **Android SDK**（仅需要命令行工具，无需 Android Studio）

---

## 第一步：安装 Android SDK

### 方式 A：手动下载 SDK 命令行工具（推荐）

```bash
# 创建 SDK 目录
mkdir -p ~/Android/sdk/cmdline-tools
cd ~/Android/sdk/cmdline-tools

# 下载命令行工具（使用清华镜像加速）
wget https://mirrors.tuna.tsinghua.edu.cn/android/repository/commandlinetools-win-11076708_latest.zip
# macOS 用: commandlinetools-mac-11076708_latest.zip
# Linux 用: commandlinetools-linux-11076708_latest.zip

# 解压并整理目录
unzip commandlinetools-*.zip
mv cmdline-tools latest
```

### 方式 B：通过 Android Studio 安装

1. 下载 [Android Studio](https://developer.android.google.cn/studio)
2. 安装后打开 Studio -> SDK Manager
3. 记下 SDK 路径（如 `C:\Users\用户名\AppData\Local\Android\Sdk`）

---

## 第二步：配置环境变量

### macOS / Linux

```bash
# 编辑 ~/.bashrc 或 ~/.zshrc
export ANDROID_HOME=$HOME/Android/sdk
export PATH=$PATH:$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools

# 生效
source ~/.bashrc  # 或 source ~/.zshrc
```

### Windows（PowerShell）

```powershell
[Environment]::SetEnvironmentVariable("ANDROID_HOME", "$env:USERPROFILE\Android\Sdk", "User")
# 重启终端
```

---

## 第三步：安装必要 SDK 组件

```bash
# 同意许可证
yes | sdkmanager --licenses

# 安装构建所需组件
sdkmanager "platform-tools" "platforms;android-34" "build-tools;34.0.0"
```

---

## 第四步：配置 SDK 路径

```bash
# 复制模板并编辑
cp local.properties.template local.properties

# 修改 local.properties 中的路径为实际 SDK 路径：
# macOS/Linux:
#   sdk.dir=/Users/你的用户名/Android/sdk
# Windows:
#   sdk.dir=C\\:\\\\Users\\\\你的用户名\\\\AppData\\\\Local\\\\Android\\\\Sdk
```

---

## 第五步：构建 APK

```bash
# 进入项目目录
cd zhongjing-medical-android

# 使用 Gradle Wrapper 构建（已配置阿里云镜像，首次会自动下载 Gradle）
./gradlew assembleRelease

# Windows 用: .\gradlew.bat assembleRelease
```

构建完成后 APK 位于：
```
app/build/outputs/apk/release/app-release-unsigned.apk
```

---

## 第六步：签名 APK（可选，用于安装）

```bash
# 生成签名密钥（首次）
keytool -genkey -v -keystore zhongjing.keystore -alias zhongjing -keyalg RSA -validity 10000

# 签名 APK
jarsigner -verbose -keystore zhongjing.keystore app/build/outputs/apk/release/app-release-unsigned.apk zhongjing

# 优化对齐
zipalign -v 4 app/build/outputs/apk/release/app-release-unsigned.apk app-release-signed.apk
```

---

## 常见问题

### 1. Gradle 下载慢

已配置阿里云镜像：
- `gradle-wrapper.properties` 中 `distributionUrl=https://mirrors.aliyun.com/gradle/distributions/v8.4.0/gradle-8.4-bin.zip`
- 如需手动下载 Gradle，访问 https://mirrors.aliyun.com/gradle/distributions/

### 2. 依赖下载慢

已在以下文件配置阿里云 Maven 镜像：
- `settings.gradle` - 插件仓库和依赖仓库
- 自动生效，无需额外操作

### 3. Could not find com.android.tools.build:gradle

检查网络连接，确保可以访问阿里云镜像。如仍失败，在 `settings.gradle` 中添加更多镜像源：

```gradle
maven { url 'https://maven.aliyun.com/repository/google' }
maven { url 'https://maven.aliyun.com/repository/public' }
maven { url 'https://maven.aliyun.com/repository/gradle-plugin' }
google()
mavenCentral()
```

### 4. 找不到 sdkmanager

确保 `ANDROID_HOME` 环境变量正确设置，且 `cmdline-tools/latest/bin` 已加入 `PATH`。

---

## 项目结构

```
zhongjing-medical-android/
├── gradlew                          # Gradle wrapper 脚本
├── gradle/
│   └── wrapper/
│       ├── gradle-wrapper.jar       # wrapper 核心
│       └── gradle-wrapper.properties # 阿里云镜像配置
├── settings.gradle                  # 项目设置 + Maven 镜像
├── build.gradle                     # 项目级构建脚本
├── local.properties.template        # SDK 路径模板
├── gradle.properties                # Gradle 属性
└── app/
    ├── build.gradle                 # 应用级构建脚本
    └── src/main/
        ├── AndroidManifest.xml      # 应用清单
        ├── assets/www/              # 嵌入的网页应用
        ├── java/com/zhongjing/medical/
        │   └── MainActivity.java    # WebView 主活动
        └── res/
            ├── layout/activity_main.xml
            ├── drawable/progress_drawable.xml
            └── values/
                ├── strings.xml
                ├── colors.xml
                └── styles.xml
```

---

## 技术说明

- **最低支持**: Android 7.0 (API 24)
- **目标版本**: Android 14 (API 34)
- **Gradle 版本**: 8.4（通过阿里云镜像自动下载）
- **应用大小**: 约 500KB（Android 层）+ 网页资源
